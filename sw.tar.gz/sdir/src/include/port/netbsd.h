/* src/include/port/netbsd.h */
